from KAYAKO_VIP_BOT_Gojo_Styled import main
main()
